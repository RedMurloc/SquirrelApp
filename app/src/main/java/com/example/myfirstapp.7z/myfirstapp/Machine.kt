package com.example.myfirstapp

class Machine {
    private var macAddress: String = ""
    private var wifiName: String = ""
    private var isActive: Boolean = false

    constructor(wifiName: String, macAddress: String, isActive: Boolean = true) {
        this.wifiName = wifiName
        this.macAddress = macAddress
        this.isActive = isActive
    }

    public fun getWifiName() : String {
        return this.wifiName
    }

    public fun getMacAddress() : String {
        return this.macAddress
    }

    public fun getMacAddressBytes() : ByteArray {
        val macAddressBytes = ByteArray(6)
        val stringBytes = macAddress.split("-")
        for (i in stringBytes.indices) {
            macAddressBytes[i] = stringBytes[i].toByte()
        }
        return  macAddressBytes
    }

    public fun isActive() : Boolean {
        return this.isActive
    }

}