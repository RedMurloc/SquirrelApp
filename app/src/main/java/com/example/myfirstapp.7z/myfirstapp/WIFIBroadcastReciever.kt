package com.example.myfirstapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.util.Log
import android.widget.Toast

open class WIFIBroadcastReceiver : BroadcastReceiver() {
    private /*lateinit*/ var TAG = "WIFIBroadcastReceiver"
    var stupidCounter = 0
    //private lateinit var wifiManager: WifiManager

    /*init {
        TAG = "WIFIBroadcastReceiver"
    }*/

    /*constructor(wifiManager: WifiManager) {
        super()
        this.wifiManager = wifiManager
    }*/

    override fun onReceive(context: Context, intent: Intent) {
        if ((intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, 228) == WifiManager.WIFI_STATE_ENABLED) /*&& (stupidCounter++ != 0)*/) {
                        Toast.makeText(context, "RECIEVED", Toast.LENGTH_LONG).show()
            for (i in 0..9) {
                SendUDPTask().execute(0)
            }
            /*StringBuilder().apply {
            append("Action: ${intent.action}\n")
            append("URI: ${intent.toUri(Intent.URI_INTENT_SCHEME)}\n")
            toString().also { log ->
                Log.d(TAG, log)
                Toast.makeText(context, log, Toast.LENGTH_LONG).show()
            }
        }*/
        }
    }
}